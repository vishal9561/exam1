import scipy.optimize
import pandas as pd


#filehandle=open('C:\\ExamProblemData2.1.xlsx','r')
#print filehandle

e=pd.ExcelFile('C:\\ExamProblemData2.1.xlsx')


sheet=e.parse(0)   # get the first sheet irrespective of the sheet name

t=sheet.icol(0).real #first column. we just take all the real data

c1=sheet.icol(1).real #second column


c=c1.size

u=c1

def curve(t,p):
    [A,B,C,D]=p
    u=A+(B*t)+(C*(t**2))+(D*(t**3))
    return u


def error(p,t,uexp):
    ucalc=curve(t,p)
    err=ucalc-uexp
    return err

umean=scipy.average(u)


sigmai=(((u-umean)**2)/c)**0.5

pguess=[1,2,3,4]

plsq=scipy.optimize.leastsq(error,pguess,args=(t,u))

p=plsq[0]

print p


