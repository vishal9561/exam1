# -*- coding: utf-8 -*-
"""
Created on Mon Mar 16 11:18:44 2015

@author: Sony
"""

a=3.0/2.0
print a