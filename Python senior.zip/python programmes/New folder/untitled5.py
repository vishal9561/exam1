# -*- coding: utf-8 -*-
"""
Created on Sun Apr 19 11:33:37 2015

@author: Sony
"""

def f(x):
    f=x**2
    return f
x=2
print(f(x))
    