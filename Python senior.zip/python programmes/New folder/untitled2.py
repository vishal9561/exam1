# -*- coding: utf-8 -*-
"""
Created on Sat Apr 18 11:40:04 2015

@author: Sony
"""

h=[2.433,3.533333]
print len(h)

a=[0.3,0.4,0.111,0.1,0]
if any(a)>1 :
    print a
else:
    print 'no'

lsT=sc.zeros(3)
T=[1,2,3]
for i in range(0,3):
   if T[i]<=1:
       lsT[i]=1
   elif T[i]>=3:
        lsT[i]=3
   else:
        lsT[i]=2
print lsT


def fun(a):
    c=a+a
    d=a*a
    return c,d
    
b=sc.array([1,2,3,4])
a=fun(b)
print a[1]
h=10
k=1
a=range(0,h,k)
print a
