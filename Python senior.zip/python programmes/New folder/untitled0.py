# -*- coding: utf-8 -*-
"""
Created on Mon Mar 16 10:45:12 2015

@author: Sony
"""

book={'dad':'ty','mom':'tc'}