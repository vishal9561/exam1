# -*- coding: utf-8 -*-
"""
Created on Sun Feb 15 11:00:29 2015

@author: Girija
"""
import scipy as sc
from scipy.interpolate import UnivariateSpline as uv
def add(a,b):
    c=a+b
    d=a*b
    return c,d
x=[1,2,3,4,5]
y=[1,4,9,16,25]

def func(x,y):
    f=uv(x,y,k=3,s=0)
    return f
f1=func(x,y)
f2=f1(26)
print f2

h=[2.433,3.533333]
print len(h)

a=[3,4,1,2,1]
if any(a)>1 :
    print a
else:
    print 'no'


lsT=sc.zeros(3)
T=[1,2,3]
for i in range(0,3):
   if T[i]<=1:
       lsT[i]=1
   elif T[i]>=3:
        lsT[i]=3
   else:
        lsT[i]=2
print lsT


def fun(a):
    c=a+a
    d=a*a
    return c,d
    
b=sc.array([1,2,3,4])
a=fun(b)
print a[1]
h=10
k=1
a=range(0,h,k)
print a
