# -*- coding: utf-8 -*-
"""
Created on Wed Jan 07 10:59:05 2015

@author: vhd
"""

import os

x=3

'''print "Hello world!"

print x

if x>1:
    print x
    print "x greater than 1"
    print "x>1"
elif x<4:
    print x
    print "x<4"
else:
    print x'''
    
y=[1.0,3,"cat",True,'pony',False,'three blind mice',os]

'''print y[1:]
print y[2:5]
print y[:7]'''

'''for x in y:
    print x'''
    
'''for i in range(len(y)):
    print y[i],i'''

x=range(101)
y=[z**2 for z in x]
import pylab
pylab.plot(x,y,'#fff8e7')
pylab.show()

        
