# -*- coding: utf-8 -*-
"""
Created on Wed Jan 28 11:01:55 2015

@author: vhd
"""

import scipy
import Process_Simulation as ps
from ps.Compounds import water,benzene
from ps.Fluids.Fluid import Fluid 
from ps.Heat_Exchangers.Class_DPHeatEx import  DPHex    #importing class Fluid from file Fluid in folder Fluids in folder Process_Simulation

w = Fluid(water)                    #creating water as an instance of Fluid class
b = Fluid(benzene)  

Hw = w.H(373.15,10**6)