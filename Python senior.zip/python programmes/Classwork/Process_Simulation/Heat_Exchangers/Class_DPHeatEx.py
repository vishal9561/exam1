# -*- coding: utf-8 -*-
"""
Created on Wed Jan 21 11:45:46 2015

@author: vhd
"""

import scipy as sc
import scipy.integrate as integ
import scipy.optimize as opt
import matplotlib.pyplot as plt

class Fluid:
    def __init__(self,m,T):
        self.m = m
        self.T = T
    
    def Cp(self,T):
        Cp=4184+10**(-4)*T+10**(-6)*T**2+10**(-9)*T**3
        return Cp

fluidhot = Fluid(1,373.15)
fluidcold = Fluid(1,303.15)

class DPHex:
    def __init__(self,U,A,n):
        self.U = U
        self.A = A
        self.n = n
#        self.fluidhot=fluidhot
#        self.fluidcold=fluidcold
        self.mh = fluidhot.m
        self.mc = fluidcold.m
        self.Thin = fluidhot.T
        self.Tcin = fluidcold.T
        self.Cph = fluidhot.Cp
        self.Cpc = fluidcold.Cp
        self.set_grid(n)
        
    def set_grid(self,n):
        self.n = n
        self.dA = self.A/(n-1)
        self.Th = sc.ones(n)*fluidhot.T
        self.Tc = sc.ones(n)*fluidcold.T
        self.Tguess = sc.concatenate((self.Th,self.Tc))
        
    def solve(self):
        Tguess = self.Tguess
        Tsoln = opt.leastsq(residuals,Tguess,args=(self))[0]
        self.Th = Tsoln[:self.n]
        self.Tc = Tsoln[self.n:]
        self.Th[0] = self.Thin
        self.Tc[-1] = self.Tcin
        
    def check(self):
        
        i1 = integ.quad(fluidhot.Cp,self.Th[-1],self.Thin)
        i2 = integ.quad(fluidcold.Cp,self.Tcin,self.Tc[0])
#       print i1
#       print i2
        i = (self.mh*i1[0]) - (self.mc*i2[0])
        errchk = (i/(self.mh*i1[0]))*100
        return errchk        
        
def residuals(T,obj):
    n=obj.n
    Th = T[:n]
    Tc = T[n:]
    Th[0] = obj.Thin
    Tc[-1] = obj.Tcin
    Cph = obj.Cph
    Cpc = obj.Cpc
    
    errHL=obj.U*(Th[0]-Tc[0])/(obj.mh*Cph(Th[0]))+(Th[1]-Th[0])/obj.dA
    errCL=obj.U*(Th[0]-Tc[0])/(obj.mc*Cpc(Tc[0]))+(Tc[1]-Tc[0])/obj.dA
    errHR=obj.U*(Th[-1]-Tc[-1])/(obj.mh*Cph(Th[-1]))+(Th[-1]-Th[-2])/obj.dA
    errCR=obj.U*(Tc[-1]-Tc[-1])/(obj.mh*Cpc(Tc[-1]))+(Tc[-1]-Tc[-2])/obj.dA
    
    errH=sc.zeros(n)
    errC=sc.zeros(n)
    
    errH[0]=errHL;errH[-1]=errHR
    errC[0]=errCL;errC[-1]=errCR
    
    errH[1:-1]=obj.U*(Th[1:-1]-Tc[1:-1])/(obj.mh*Cph(Th[1:-1]))+(Th[2:]-Th[1:-1])/obj.dA
    #errH[1:-1]=U*(Th[1:-1]-Tc[1:-1])/(Mh*Cph(Th[1:-1]))+(Th[2:]-Th[0:-2])/dA for central difference
    errC[1:-1]=obj.U*(Th[1:-1]-Tc[1:-1])/(obj.mc*Cpc(Tc[1:-1]))+(Tc[2:]-Tc[1:-1])/obj.dA
    err = sc.concatenate((errH,errC))
    
    return err
        
n = 10
listerr = []
nrange = []

hex1 = DPHex(300,1000,n) #instance of class DPHex

#for i in range(2,102,20):
#    n = i
#    nrange += [n]
hex1.set_grid(n)
hex1.solve()
#    err = hex1.check()
#    listerr += [err]
#   print err1
print hex1.Tc
print hex1.Th
#plt.plot(nrange,listerr)
##plt.plot(sc.log(nrange),sc.log(listerr))
#plt.title("Error vs Grid Size")
#plt.xlabel("Grid Size") 
#plt.ylabel('Error')
#plt.show()