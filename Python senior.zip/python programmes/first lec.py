# -*- coding: utf-8 -*-
"""
Created on Sun Jan 18 13:27:45 2015

@author: Sony
"""


print 'hello'
import os
print os.getcwd()
x=3
if x>2:
    print 'x greater than 2'
    print 'xx xx'
elif x>4:
    print' x more than 2 or less than 4'
else:
    print x
y= [1,3,'cat',4.0,True,83.67]
for x in y:
    print x
x=range(0,30);
y=[xx**2 for xx in x]
import pylab
pylab.plot(x,y,'g')
 