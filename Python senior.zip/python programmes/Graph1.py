# -*- coding: utf-8 -*-
"""
Created on Tue Jan 20 00:05:57 2015

@author: Nitish
"""

import matplotlib.pyplot as plt
import scipy as sp 

fig=plt.figure(num=None, figsize=(10, 10), dpi=80, facecolor='w', edgecolor='k')
ax=fig.add_subplot(111)
fig.show()
#ax.set_xlim([0, 40])
#ax.set_ylim([-1.3,1.3])

for a in sp.linspace(0,10*sp.pi,100):
    
    if sp.sin(a) < 0:
        line = plt.Line2D((a, a), (-sp.sin(a), sp.sin(a)), lw=2.5,color='r')
        plt.gca().add_line(line)
        plt.pause(0.01)
        plt.axis('scaled')
    else:
        line = plt.Line2D((a, a), (-sp.sin(a), sp.sin(a)), lw=2.5,color='y')
        plt.gca().add_line(line)
        plt.pause(0.01)
        plt.axis('scaled')
    