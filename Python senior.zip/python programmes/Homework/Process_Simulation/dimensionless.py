# -*- coding: utf-8 -*-
"""
Created on Sun Feb 01 12:52:02 2015

@author: prasad
"""

import scipy as sc
#from Fluids import Fluid
#from Compounds import water,benzene

class Dimlessno:
    def __init__(self,T,P,m,d,fluidproperties):
        self.props = fluidproperties
        self.m = m
        self.T = T
        self.P = P
        
    def Re(self,T,P,d,m):
        p = self.props
        
        if P < p.Psat :
            mu = p.Viscg
            rho = p.Mw * P/(8.314 * T)
            v = ( m / rho ) / ((sc.pi*d**2)/4)
        else :
            mu = p.Viscl
            rho = p.Densl
            v = ( m / rho ) / ((sc.pi*d**2)/4)
        
        Re = d*v*rho/mu
        return Re

    def Pr(self,P,T):
        p=self.props
        
        if P < p.Psat :
            mu = p.Viscg
        else :
            mu = p.Viscl
            
        
        Pr = (p.Cp(self.T) * mu )/( p.k(self.T))
        return Pr

    def NuL(d,L,Re,Pr): # for Turbulent flow
        c=1 # c=mu/muw=1
        NuT=1.86*(((d/L)*Re*Pr)**(1/3))*c #valid for (Re*Pr*(d/L))<10;Pr=0.48-16700
        return NuT
    
    def NuT(Re,Pr,n):
        NuL=0.023*(Re**0.8)*Pr**n
        return NuL

