# -*- coding: utf-8 -*-
"""
Created on Tue Feb 03 19:11:00 2015

@author: Nitish
"""

import scipy as sc
import scipy.integrate as integ
import scipy.optimize as opt
import matplotlib.pyplot as plt
import pylab

#class Fluid:
#    def __init__(self,m,T,fluidprops):
#        self.m = m
#        self.T = T
#    
#    def Cp(self,T):
#        Cp=4184+10**(-4)*T+10**(-6)*T**2+10**(-9)*T**3
#        return Cp
#
#hot = Fluid(1,373.15)
#cold = Fluid(2,303.15)

class DPHex:
    def __init__(self,U,A,n,hot,cold):
        self.U = U
        self.A = A
        self.n = n
        self.mh = hot.m
        self.mc = cold.m
        self.Thin = hot.T
        self.Tcin = cold.T
        self.Cph = hot.Cp
        self.Cpc = cold.Cp
        self.set_grid(n)
        
    def set_grid(self,n):
        self.n = n
        self.dA = self.A/(n-1)
        self.Th = sc.ones(n)*self.Thin
        self.Tc = sc.ones(n)*self.Tcin
        self.Tguess = sc.concatenate((self.Th,self.Tc))
        
    def solve(self):
        Tguess = self.Tguess
        Tsoln = opt.leastsq(residuals,Tguess,args=(self))[0]
        self.Th = Tsoln[:self.n]
        self.Tc = Tsoln[self.n:]
        self.Th[0] = self.Thin
        self.Tc[-1] = self.Tcin
        
    def check(self):
        
        i1 = integ.quad(self.Cph,self.Th[-1],self.Thin)
        i2 = integ.quad(self.Cpc,self.Tcin,self.Tc[0])
#       print i1
#       print i2
        i = (self.mh*i1[0]) - (self.mc*i2[0])
        errchk = (i/(self.mh*i1[0]))*100
        return errchk        
        
def residuals(T,obj):
    n=obj.n
    Th = T[:n]
    Tc = T[n:]
    Th[0] = obj.Thin
    Tc[-1] = obj.Tcin
    Cph = obj.Cph
    Cpc = obj.Cpc
    
    errHL=obj.U*(Th[0]-Tc[0])/(obj.mh*Cph(Th[0]))+(Th[1]-Th[0])/obj.dA
    errCL=obj.U*(Th[0]-Tc[0])/(obj.mc*Cpc(Tc[0]))+(Tc[1]-Tc[0])/obj.dA
    errHR=obj.U*(Th[-1]-Tc[-1])/(obj.mh*Cph(Th[-1]))+(Th[-1]-Th[-2])/obj.dA
    errCR=obj.U*(Tc[-1]-Tc[-1])/(obj.mh*Cpc(Tc[-1]))+(Tc[-1]-Tc[-2])/obj.dA
    
    errH=sc.zeros(n)
    errC=sc.zeros(n)
    
    errH[0]=errHL;errH[-1]=errHR
    errC[0]=errCL;errC[-1]=errCR
    
    errH[1:-1]=obj.U*(Th[1:-1]-Tc[1:-1])/(obj.mh*Cph(Th[1:-1]))+(Th[2:]-Th[1:-1])/obj.dA
    #errH[1:-1]=U*(Th[1:-1]-Tc[1:-1])/(Mh*Cph(Th[1:-1]))+(Th[2:]-Th[0:-2])/dA for central difference
    errC[1:-1]=obj.U*(Th[1:-1]-Tc[1:-1])/(obj.mc*Cpc(Tc[1:-1]))+(Tc[2:]-Tc[1:-1])/obj.dA
    err = sc.concatenate((errH,errC))
    
    return err
        
#n = 100
#
#hex1 = DPHex(300,100,n) #instance of class DPHex
#
#hex1.set_grid(n)
#hex1.solve()
#    
#print hex1.Tc
#print hex1.Th
#
#x = range(0,hex1.A,hex1.A/n)
#pylab.plot(x,hex1.Th)
#pylab.plot(x,hex1.Tc)
#pylab.show() 