# -*- coding: utf-8 -*-
"""
Created on Wed Jan 28 11:00:01 2015

@author: vhd
"""

import scipy
from scipy.integrate import quad

class Fluid:
    def __init__(self,m,T,P,fluidproperties):
        self.props = fluidproperties
        p = self.props
        self.m = m
        self.T = T
        self.Psat = p.Psat(T)
        self.Viscl = p.Viscl(T)
        self.Viscg = p.Viscg(T)
        self.Densl = p.Densl(T)
        self.Densg = p.Densg(T)
        self.k = p.k(T)
        
        if P < p.Psat(T):
            self.Cp = p.Cpg
        else:
            self.Cp = p.Cpl
    
    def H(self,T,P):
        p = self.props
        Psat = p.Psat(T) 
#OR     Psat = self.props.Psat(T)
        
        if P < Psat : # is gas
            H = p.Hf + quad(p.Cpg,p.Tf,T)
        else:
            H = p.Hf + quad(p.Cpg,p.Tf,T) - p.Hvap(T)
        return H
#    
#    def Re(self,T,P,dh,v):
#        p=self.props
#        Psat = p.Psat(T)
#        
#        if P < Psat :
#            mu = p.viscG(T,P)
#            rho = p.Mw*P/(8.314*T)
#        else :
#            mu = p.viscL(T,P)
#            rho = p.densL(T,P)
#        
#        Re = dh*v*rho/mu
#        return Re