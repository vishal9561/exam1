# -*- coding: utf-8 -*-
"""
Created on Wed Jan 28 11:00:01 2015

@author: vhd
"""

import scipy as sc
from scipy.integrate import quad
from scipy.interpolate import UnivariateSpline as us

temp = sc.linspace(250,500,50)

class Fluid:
    def __init__(self,m,T,P,fv,fluidproperties):
        self.props = fluidproperties
        p = self.props
        self.m = m
        self.P = P
        self.fv = fv
        self.T = T
        self.Psat = p.Psat(T)
        self.Viscl = p.Viscl(T)
        self.Viscg = p.Viscg(T)
        self.Densl = p.Densl(T)
        self.Densg = p.Densg(T)
        self.k = p.k(T)
        
#        if P < p.Psat(T):
#            self.Cp = p.Cpg
#        else:
#            self.Cp = p.Cpl
    
    def Hl(self,T):
        p = self.props
        
        Hl = p.Hf + quad(p.Cpg,p.Tf,T) - p.Hvap(T)
        return Hl
    
    def Hv(self,T):
        p = self.props
        
        Hv = p.Hf + quad(p.Cpg,p.Tf,T)   
        return Hv
        
    def H(self,T,fv):
        H = (1-fv)*self.Hl(T) + fv*self.Hv(T)
        return H
        
    def interpolate(self,H):
        p = self.props
        
        Hl = p.Hl(temp)
        Hv = p.Hv(temp)

        Hlsat = Hl(p.Tsat(self.P))
        Hvsat = Hv(p.Tsat(self.P))
        
        TL = us(Hl,temp,k=3,s=0)
        TV = us(Hv,temp,k=3,s=0)
        
        if H < Hlsat:
            T = TL(H)
            
        elif H > Hvsat :
            T = TV(H)
            
        else: 
            T = p.Tsat(self.P)
        
        return T