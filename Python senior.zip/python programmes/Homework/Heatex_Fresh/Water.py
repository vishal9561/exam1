import scipy as sc

"""WATER"""
#------------------------------------------------------------------------------
MW=18.015 #g/mol
formula="H2O"
TriplePoint_T = 273.16 #K
Triplepoint_P = 611.73 #Pa
Ts1=373 #K
Ps1=101325 #Pa
R=8.314 #J.mol-1.K-1
Tf=298 #K

#------------------------------------------------------------------------------
'''CRITICAL CONSTANTS'''
Tc = 647.10 #K 
Pc = 22.064*10**6 #Pa
Zc = 0.229
Vc = 0.0559472 #m3/kmol
accf = 0.3449
#------------------------------------------------------------------------------
'''PHASE BEHAVIOR (STANDARD CONDITIONS)'''
Hfusion = 6.01*1000 #J/mol
Hsublimation = 46.70*1000 #J/mol
#------------------------------------------------------------------------------
'''IDEAL GAS - HEATS AND FREE ENERGIES OF FORMATION'''
Hf = -24.1814*10**7 #J/kmol @ 25oC and 1 bar (ideal gas)
Gf = -22.859*10**7 #J/kmol @ 25oC and 1 bar (ideal gas)
Sf = 1.88724*10**5 #J/kmol-K @ 25oC and 1 bar (ideal gas)
#------------------------------------------------------------------------------
'''SPECIFIC HEATS'''

def Cpl(T):     #J/kmol-K Trange = 273.16K - 533.15K
    c1 = 2.7637*10**5
    c2 = -2.0901*10**3
    c3 = 8.125
    c4 = -1.4116*10**(-2)
    c5 = 9.370*10**(-6) 
    cpl = c1+c2*T+c3*T**2+c4*T**3+c5*T**4
    return cpl 
    
def Cpg(T):     #J/kmol-K Trange = 100C - 1000C (fitting done R2 = 0.99989) 
    c1 = -2*10**(-9)
    c2 = 2*10**(-5)
    c3 = -0.0152
    c4 = 40.162
    cpg=c1*T**3+c2*T**2+c3*T+c4
    return cpg 
    
def Cvg(T):     #J/kmol-K Trange = 100C - 1000C (fitting done R2 = 0.99964)
   c1 = 4*10**(-9)
   c2 = -1*10**(-6)
   c3 = -0.0013
   c4 = 27.952
   cvg = c1*T**3+c2*T**2+c3*T+c4
   return cvg
def gamma(T):   
    gamma = Cpg(T)/Cvg(T)
    return gamma 
#------------------------------------------------------------------------------        
'''VAPORISATION ENTHALPY'''
def Hvap(T):     #J/kmol between 273.16K and 647.10K
    C1 = 5.2053*10**7
    C2 = 0.3199
    C3 = -0.212
    C4 = 0.25795
    C5 = 0
    Tr = T/Tc
    Hv = C1*(1-Tr)**(C2 + C3*Tr + C4*Tr**2 + C5*Tr**3)   
    return Hv
#------------------------------------------------------------------------------    
'''VAPOR PRESSURE'''
def Psat(T):     #Pa
    if T < 573 and T > 379:
        A = 3.55959
        B = 643.748
        C = -198.043
    elif T < 374 and T > 255.9:
        A = 4.6543
        B = 1435.264
        C = -64.848
        
    k = A - B / (T + C) 
    vp = (10**k) * 10**5
    return vp
#------------------------------------------------------------------------------    
'''DENSITY'''
def Densl(T):   #kmol/m3
    if T>273.16 and T<333.15:
        c1 = 5.459
        c2 = 0.30542
        c3 = 647.13
        c4 = 0.081
    elif T>333.15 and T<403.15:
        c1 = 4.9669
        c2 = 2.7788*10**(-1)
        c3 = 647.13
        c4 = 0.18740 
    elif T>403.15 and T<647.13:
        c1 = 4.391
        c2 = 0.2487
        c3 = 647.13
        c4 = .2534
    rhoL = c1/(c2**(1+(1-(T/c3)**c4)))
    return rhoL 

def Densg(T): 
    c1 = 3*10**(-8)
    c2 = -2*10**(-5)
    c3 = 0.0063
    c4 = -0.5859
    rhoG = c1*T**3+c2*T**2+c3*T+c4
    return rhoG
#------------------------------------------------------------------------------
'''VISCOSITY'''
def Viscl(T):     #Pa.s
    return 0.001

def Viscg(T):     #Pa.s
   return 10**(-5)
#------------------------------------------------------------------------------   
'''THERMAL CONDUCTIVITY'''
def k(T):   #W/m-K
    c1 = 6.204*10**(-6)
    c2 = 1.3973
    c3 = 0
    c4 = 0
    k = (c1*T**(c2))/(1+c3/T+c4/(T**2))
    return k
#------------------------------------------------------------------------------    
'''clausias clapeyron eq'''
def Ps(T):
    return Ps1*exp(-(Hvap(Tf)/R)*(T**-1-Ts1**-1))
    
    