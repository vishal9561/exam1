# -*- coding: utf-8 -*-
"""
Created on Tue Feb 17 17:52:45 2015

@author: prasad
"""
import scipy as sc
import scipy.optimize as opt
from Process_Simulation.Compounds import Water
from scipy.interpolate import UnivariateSpline as us
from scipy.integrate import quad
n = 10
L = 100
Hai = -2.6*10**8
Hbi = -1.5*10**8
Tai = 373
Tbi = 303
Tsata = Tsatb = 373
Af = 1 #m2
At = 100 
ma = mb = 1 
dx = L/(n-1)
dAt = At/(n-1)
Hlsata = -2.3 * 10**8
Hvsata = -1.8 * 10**8
Hlsatb = Hlsata
Hvsatb = Hvsata
kga = kgb = 0.02 # J.mol-1.K-1
U = 300
p = Water
temp = sc.linspace(250,500,n)

Hla = sc.zeros(n)
Hva = sc.zeros(n)
Hlb = sc.zeros(n)
Hvb = sc.zeros(n)
        
        
#Hlsata = Hl(Tsata)
#Hvsata = Hv(Tsata)
#Hlsatb = Hl(Tsatb)
#Hvsatb = Hv(Tsatb)
        
TLa = us(Hla,temp,k=3,s=0)
TVa = us(Hva,temp,k=3,s=0)
TLb = us(Hlb,temp,k=3,s=0)
TVb = us(Hvb,temp,k=3,s=0)
        
        
def fvap(H,Hlsat,Hvsat):
        
    if H < Hlsat:
        fv = 0
    elif H < Hvsat:
        fv = 1
    else:
        fv = (H-Hlsat)/(Hvsat-Hlsat)
               
    return fv
def kl(T):   #W/m-K
    c1 = 6.204*10**(-6)
    c2 = 1.3973
    c3 = 00.0
    c4 = 0.0
    l = ((c1*T**(c2))/(1+c3/T+c4/(T**2)))
    return l
def kg(T): #Trange = 273.16 - 1073.15
    c1 = 6.2041*10**(-6)
    c2 = 1.3973
    c3 = 0
    c4 = 0 
    k = (c1*T**c2)/(1+c3/T+c4/T**2)
    return k

def Hl(T):
  #  p = self.props
        
    Hl = p.Hf + quad(p.Cpg,p.Tf,T)[0] - p.Hvap(T)
    return Hl
    
def Hv(T):
    #p = self.props
        
    Hv = p.Hf + quad(p.Cpg,p.Tf,T)[0]  
    return Hv
        
def H(T,fv):

    H = (1-fv)*Hl(T) + fv*Hv(T)
    return H

for i in range (0,n):
    Hla[i] = Hl(temp[i])
    Hva[i] = Hv(temp[i])
    Hlb[i] = Hl(temp[i])
    Hvb[i] = Hv(temp[i])


def interpolate(H,Hlsat,Hvsat,TL,TV,Tsat):
    #print H
    if H < Hlsat:
        t = TL(H)
            
    elif H > Hvsat :
        t = TV(H)
            
    else: 
        t = Tsat
    
    return t
    

def residuals(Hguess,Hai,Hbi,Tai,Tbi):
    Ha = Hguess[:n]
    Hb = Hguess[n:]
    Ha[0] = Hai
    Hb[-1] = Hbi
    
#    Ta = sc.ones(n)
#    Tb = sc.ones(n)
#    for i in range(0,n):
#        Ta[i] = Ta[i]*Tai
#        Tb[i] = Tb[i]*Tbi
#        Ta[i] = interpolate(Ha[i],Hlsata,Hvsata,TLa,TVa,Tsata)
#        Tb[i] = interpolate(Hb[i],Hlsatb,Hvsatb,TLb,TVb,Tsatb)
#    print Ta
#    print Tb
    
    dhAdx = sc.zeros(n)
    dhBdx = sc.zeros(n)
    dhAdx[:-1] = (Ha[1:]-Ha[:-1])/dx
    dhBdx[:-1] = (Hb[1:]-Hb[:-1])/dx
    dhAdx[-1] = (Ha[-1]-Ha[-2])/dx
    dhBdx[-1] = (Hb[-1]-Hb[-2])/dx
#    print dhAdx
#    print dhBdx
    
    dTAdx = sc.zeros(n)
    dTBdx = sc.zeros(n)
    dTAdx[:-1] = (Ta[1:]-Ta[:-1])/dx
    dTBdx[:-1] = (Tb[1:]-Tb[:-1])/dx
    dTAdx[-1] = (Ta[-1]-Ta[-2])/dx
    dTBdx[-1] = (Tb[-1]-Tb[-2])/dx
##
    Ka = [] 
    for x in range(0,n):
        Ka = sc.append(Ka,fvap(Ha[x],Hlsata,Hvsata)*kg(Ta[x])+(1-fvap(Ha[x],Hlsata,Hvsata)*kl(Ta[x]))) # here kl is kla
    print Ka    
    Kb = []
    for x in range(0,n):
        Kb = sc.append(Kb,fvap(Hb[x],Hlsatb,Hvsatb)*kg(Tb[x])+(1-fvap(Hb[x],Hlsatb,Hvsatb)*kl(Tb[x]))) # here kl is klb...for the sake f ocnv        
    print Kb
    dKa = sc.zeros(n)
    dKb = sc.zeros(n)
    
    dKa[-1] = (Ka[-1]*Af*dTAdx[-1]-Ka[-2]*Af*dTAdx[-2])/dx 
    dKa[:-1] = (Ka[1:]*Af*dTAdx[1:]-Ka[:-1]*Af*dTAdx[:-1])/dx 
    
    dKb[-1] = (Kb[-1]*Af*dTBdx[-1]-Kb[-2]*Af*dTBdx[-2])/dx 
    dKb[:-1] = (Kb[1:]*Af*dTBdx[1:]-Kb[:-1]*Af*dTBdx[:-1])/dx 

    errA = sc.zeros(n)
    errB = sc.zeros(n) 
    
    errA[:] = ma*dhAdx[:]+U*(dAt/dx)*(Ta[:]-Tb[:])-dKa[:]
    errB[:] = mb*dhBdx[:]+U*(dAt/dx)*(Ta[:]-Tb[:])+dKb[:]   
    err = sc.concatenate((errA,errB))
    return err
Ta = sc.ones(n)
Tb = sc.ones(n)
for i in range(0,n):
    Ta[i] = Ta[i]*Tai
    Tb[i] = Tb[i]*Tbi
Hguess = sc.linspace(Hai,Hbi,20)     
soln = opt.leastsq(residuals,Hguess,args=(Hai,Hbi,Tai,Tbi))
Hsoln = soln[0]
HA = Hsoln[:n]
HB = Hsoln[n:]

print HA
print HB


for i in range(0,n):
    TA = sc.array(interpolate(h,Hlsata,Hvsata,TLa,TVa,Tsata) for h in HA)
    TB = sc.array(interpolate(h,Hlsatb,Hvsatb,TLb,TVb,Tsatb) for h in HB)

#        self.HA[0] = self.Hai
#        self.HB[-1] = self.Hbi
#print TA
#print TB            