# -*- coding: utf-8 -*-
"""
Created on Wed Jan 28 10:59:27 2015

@author: priyanka_pole
"""


import matplotlib.pyplot as plt
import Compounds as cs
import scipy as sc
from scipy.interpolate import UnivariateSpline as spl
import scipy.integrate.quad as scq
tmax=573.16
tmin=298.16
t=sc.linspace(tmin,tmax,30)
tf=273
mfl=2
class Fluid:
    def __init__(self,fluidproperties):
        self.props=fluidproperties
        
    def Hl(T):
        Hl=cs.Water.Hf+mfl*scq(cs.Water.CpG,tf,t)-cs.Water.Hvap(T)
        return Hl
    def Hg(T):
        Hg=cs.Water.Hf+mfl*scq(cs.Water.CpG,tf,t)   
        return Hg
    HL=Hl(t)
    HG=Hg(t)
    P=101325*2       
    TL=spl(HL,t,k=3,s=0)
    TG=spl(HG,t,k=3,s=0)
    T=spl(P,t,k=3,s=0)
    

    
#    def Re(self,T,P,dh,v):
#        p=self.props
#        Psat=p.Psat(T)
#        if P<Psat:
#            mu=p.viscG(T,P)
#            rho=p.MW*P/(8314*T)
#        else:
#            mu=p.viscL(T,P)
#            rho=p.densL(T,P)
#        Re=dh*v*rho/mu
#        return Re
#    