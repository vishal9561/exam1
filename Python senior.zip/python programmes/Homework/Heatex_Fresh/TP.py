# -*- coding: utf-8 -*-
"""
Created on Sat Feb 14 22:44:00 2015

@author: Nitish
"""

import scipy as sc
from scipy.integrate import quad

Tf = 288
Tsat = 373
Temp = sc.linspace(Tcin,Thin,30)

def Hl(T):
    Hl = p.Hf + quad(p.Cpg,p.Tf,T) - p.Hvap(T)
    return Hl
    
def Hv(T):
    Hv = p.Hf + quad(p.Cpg,p.Tf,T)   
    return Hv

hl = Hl(Temp)
hv = Hv(Temp)

Hlsat = Hl(Tsat)
Hvsat = Hv(Tsat)

if H < Hlsat : # is gas
    TL=spl(HL,t,k=3,s=0)
    
elif H > Hvsat :
    TG=spl(HG,t,k=3,s=0)
else: 
    T = Tsat
    