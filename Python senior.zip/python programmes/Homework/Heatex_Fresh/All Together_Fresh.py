# -*- coding: utf-8 -*-
"""
Created on Wed Jan 28 11:01:55 2015

@author: vhd
"""

import scipy as sc
from Process_Simulation.Compounds import Water,Benzene
from Process_Simulation.Fluids.Fluid import Fluid 
from Process_Simulation.Heat_Exchangers.DPHeatEx_Modified import  DPHex    #importing class Fluid from file Fluid in folder Fluids in folder Process_Simulation
import matplotlib.pyplot as plt
from Process_Simulation import op_cond
import pylab

Thin = op_cond.
Tcin = op_cond.
P = op_cond.
m1 = op_cond.
m2 = op_cond.
fva = op_cond.
fvb = op_cond.

f1 = Fluid(m1,Thin,P,fva,Water)                    #creating water as an instance of Fluid class
f2 = Fluid(m2,Tcin,P,fvb,Water)
#b = Fluid(2,373.15,101325,Benzene)

#n=int(input("Enter the number of interval:" ))
n=100
hex1 = DPHex(300,n,f1,f2) #instance of class DPHex

hex1.set_grid(n)
hex1.solve()

x = range(0,hex1.A,hex1.A/n)
pylab.plot(x,hex1.Th)
pylab.plot(x,hex1.Tc)
pylab.show()  
