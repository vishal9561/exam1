# -*- coding: utf-8 -*-
"""
Created on Wed Jan 28 11:39:40 2015

@author: vhd
"""

import scipy as sc
import scipy.integrate as integ
import scipy.optimize as opt
import matplotlib.pyplot as plt
import Compounds as cd 
from Process_Simulation import op_cond

class DPHex:
    def __init__(self,U,n,FA,FB):
        self.Af = op_cond.Af
        self.L = op_cond.L
        self.FA = FA
        self.FB = FB
        self.n = n
        self.P = op_cond.P
        self.ma = FA.m
        self.mb = FB.m
        self.Thin = FA.T
        self.Tcin = FB.T
        self.set_grid(n)
        self.Ka = FA.K(FA.T)
        self.Kb = FB.K(FB.T)
        self.Hai = FA.H(FA.T,FA.fv)
        self.Hbi = FB.H(FB.T,FB.fv)
        self.fvA = FA.fv
        self.fvB = FB.fv
        
    def set_grid(self,n):
        self.n = n
        self.dX = self.L/(n-1)
        self.Ha = sc.linspace(self.Hai,self.Hai-15,n)
        self.Hb = sc.linspace(self.Hbi,self.Hbi+15,n)
        self.Hguess = sc.concatenate(self.Ha,self.Hb)
        
    def solve(self):
        Hguess = self.Hguess
        Hsoln = opt.leastsq(residuals,Hguess,args=(self))
        self.HA = Hsoln[:self.n]
        self.HB = Hsoln[self.n:]
        self.TA = self.FA.interpolate(self.HA)
        self.TB = self.FB.interpolate(self.HB)
        self.HA[0] = self.Hai
        self.HB[-1] = self.Hbi
     
#    def check(self):
#        errchk=(self.Ha[9]-self.Ha[0])-(self.Hb[0]-self.Hb[-1])
#        i1 = integ.quad(FA.Cp,self.Th[-1],self.Thin)
#        i2 = integ.quad(FB.Cp,self.Tcin,self.Tc[0])
##       print i1
##       print i2
#        i = (self.mh*i1[0]) - (self.mc*i2[0])
#        errchk = (i/(self.mh*i1[0]))*100
#        return errchk      
        
        
def residuals(H,obj):
    n=obj.n
    Ha = H[:n]
    Hb = H[n:]
    Ta=obj.interpolate(Ha)
    Tb=obj.interpolate(Hb)
    Ha[0] = obj.hai
    Hb[-1] = obj.hbi
    
#    Cph = obj.Cph
#    Cpc = obj.Cpc
        
    errAL=Af*((obj.Ka(Ta[1])-obj.Ka(Ta[0]))/(Ta[1]-Ta[0]))*((Ta[1]-Ta[0])/obj.dX)**2+obj.Ka(Ta[0])*Af*((Ha[2]-2*Ha[1]+Ha[0])/obj.dX**2)+obj.ma*((Ha[1]-Ha[0])/obj.dX)+obj.U*(At/obj.dX)*(Ta[0]-Tb[0])
    errBR=Af*((obj.Kb(Tb[-1])-obj.Kb(Tb[-2]))/(Tb[-1]-Tb[-2]))*((Tb[-1]-Tb[-2])/obj.dX)**2+obj.Kb(Tb[-1])*Af*((Hb[-1]-2*Hb[-2]+Hb[-3])/obj.dX**2)+obj.mb*((Hb[-1]-Hb[-2])/obj.dX)+obj.U*(At/obj.dX)*(Ta[0]-Tb[0])

    errAR=Af*((obj.Ka(Ta[-1])-obj.Ka(Ta[-2]))/(Ta[-1]-Ta[-2]))*((Ta[-1]-Ta[-2])/obj.dX)**2+obj.Ka(Ta[-1])*Af*((Ha[-1]-2*Ha[-2]+Ha[-3])/obj.dX**2)+obj.ma*((Ha[-1]-Ha[-2])/obj.dX)+obj.U*(At/obj.dX)*(Ta[-1]-Tb[-1])
    errBL=Af*((obj.Kb(Tb[1])-obj.Kb(Tb[0]))/(Tb[1]-Tb[0]))*((Tb[1]-Tb[0])/obj.dX)**2+obj.Kb(Tb[1])*Af*((Hb[2]-2*Hb[1]+Hb[0])/obj.dX**2)+obj.mb*((Hb[1]-Hb[0])/obj.dX)+obj.U*(At/obj.dX)*(Ta[0]-Tb[0])

    errA=sc.zeros(n)
    errB=sc.zeros(n)
   
    errA[0]=errAL; errA[-1]=errAR
    errB[0]=errBL; errB[-1]=errBR

    errA[1:-2]=Af*((obj.Ka(Ta[2:])-obj.Ka(Ta[0:8]))/(Ta[2:]-Ta[0:8]))*((Ta[2:]-Ta[0:8])/(2*obj.dX))**2+obj.Ka(Ta[-1])*Af*((Ha[2:]-2*Ha[1:8]+Ha[0:9])/obj.dX**2)+obj.ma*((Ha[2:]-Ha[0:8])/(2*obj.dX))+obj.U*(At/obj.dX)*(Ta[1:-1]-Tb[1:-1])
    errB[1:-2]=Af*((obj.Kb(Tb[2:])-obj.Kb(Tb[0:8]))/(Tb[2:]-Tb[0:8]))*((Tb[2:]-Tb[0:8])/(2*obj.dX))**2+obj.Kb(Tb[-1])*Af*((Hb[2:]-2*Hb[1:8]+Hb[0:9])/obj.dX**2)+obj.mb*((Hb[2:]-Hb[0:8])/(2*obj.dX))+obj.U*(At/obj.dX)*(Ta[1:-1]-Tb[1:-1])

    err = sc.concatenate((errA,errB))
    
    return err
        
