# -*- coding: utf-8 -*-
"""
Created on Mon Feb  2 20:40:00 2015

@author: Samaung
"""
import imp
modl=imp.load_source('Alltogether','C:\Users\prasad\Documents\python\My Folder\Alltogether.py')

# m,tsor,dti,dto,dai,lpipe,
mt=input("Enter mass flow rate of fluid on tube side:")
ma=input("Enter mass flow rate of fluid on annulus side:")
tsr=input("Enter Surrounding Tempearture:")
dti=input("Enter tube inside diameter:")
dto=input("Enter tube outside diameter:")
dai=input("Enter inside diameter of annulus:")
lpipe=input("Enter length of heat exchanger:")
thi=input("Enter the inlet temp of hot fluid:")
tci=input("Enter the inlet temp of clod fluid:")
permPt=("Enter the permissible pressure drop for tube side:") #Pa
permPa=("Enter the permissible pressure drop for annulus side:") #Pa
print modl.n

