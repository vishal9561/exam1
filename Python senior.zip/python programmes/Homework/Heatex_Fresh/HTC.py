# -*- coding: utf-8 -*-
"""
Created on Sat Feb 14 18:30:06 2015

@author: Nitish
"""

import scipy as sc
import scipy.integrate as integ
import scipy.optimize as opt
import matplotlib.pyplot as plt
import pylab

a = 0.0
b = 0.9

def U(fva,fvb):
    if fva == 0.0 & fvb == 0.0:
        U = 50
    elif (fva == 0.0 & 0.0 <fvb < 1.0)|(fvb == 0.0 & 0 < fva < 1.0):
        U = 100
    elif (0.0 < fva < 1.0 & 0.0 < fvb < 1.0):
        U = 1000
    elif (0.0 < fva < 1.0 & fvb == 1.0)|(fva == 1.0 & 0.0 < fvb < 1.0):
        U = 10
    elif (fva == 1.0 & fvb == 1.0):
        U = 5
    else:
        U= 500
    return U

print U(a,b)
