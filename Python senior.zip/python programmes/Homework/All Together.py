# -*- coding: utf-8 -*-
"""
Created on Wed Jan 28 11:01:55 2015

@author: vhd
"""

import scipy as sc
#import Process_Simulation as ps
from Process_Simulation.Compounds import Water,Benzene
from Process_Simulation.dimensionless import Dimlessno
from Process_Simulation.Fluids.Fluid import Fluid 
from Process_Simulation.Heat_Exchangers.DPHeatEx_Modified import  DPHex    #importing class Fluid from file Fluid in folder Fluids in folder Process_Simulation
import matplotlib.pyplot as plt
import pylab

w1 = Fluid(1,373.15,101325,Water)                    #creating water as an instance of Fluid class
w2 = Fluid(2,303.15,101325,Water)
#b = Fluid(2,373.15,101325,Benzene)

#n=int(input("Enter the number of interval:" ))
n=100
hex1 = DPHex(300,100,n,w1,w2) #instance of class DPHex

hex1.set_grid(n)
hex1.solve()
    
print hex1.Tc
print hex1.Th

x = range(0,hex1.A,hex1.A/n)
pylab.plot(x,hex1.Th)
pylab.plot(x,hex1.Tc)
pylab.show()   

#Hw = w.H(373.15,10**6)


#Reynolds = Dimlessno(373.15,101325,1,1,w1)
#print Reynolds.Re(373.15,101325,1,1)


