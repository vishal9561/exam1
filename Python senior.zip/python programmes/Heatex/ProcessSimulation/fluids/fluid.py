# -*- coding: utf-8 -*-
"""
Created on Wed Feb 11 10:06:46 2015

@author: vhd
"""

import scipy as sc

from scipy.interpolate import UnivariateSpline as uv
import scipy.integrate as integ
from scipy.integrate import quad
import equipment as equip


class Fluid:
    def __init__(self,fluidproperties):
        self.props=fluidproperties
        self.n=equip.n
        
    def Hlv(self,T,P,Tsat):
        p=self.props
        Psat=p.Psat(T)
        if P<Psat:#gas
            (H1,er)=quad(p.CpG,p.Tf,T)
            H=p.Hf+H1
        else:
            (H1,er)=quad(p.CpG,p.Tf,T)
            H=p.Hf+H1-p.Hv(Tsat)
        return H
    def Hv(self,T):
        p=self.props
        #gas
        (Hv1,er)=quad(p.CpG,p.Tf,T)
        Hv=Hv1+p.Hf
        #Hl=p.Hf+scipy.integrate.quad(p.CpG,p.Tf,T)-p.Hv(T)
        return Hv
    
    def TfromPsat(self,psat,T):
       
        f=uv(psat,T,k=3,s=0)
       
        return f
    def Hl(self,T,Tsat):
        p=self.props
        
        #gas
        (Hl1,er)=quad(p.CpG,p.Tf,T)-p.Hv(Tsat)
        Hl=p.Hf+Hl1
        return Hl 
        
    def TfromHv(self,T,Hv):
        
        f=uv(Hv,T,k=3,s=0)
  
        return f
        
    def TfromHl(self,T,Hl):
       
        f=uv(Hl,T,k=3,s=0)
       
        return f
        
#    def fv(self,H,P):
#        Tsat=self.TfromPsat(P)
#        Hvsat=self.Hv(Tsat)
#        Hlsat=self.Hl(Tsat)
#        if H<Hvsat:
#            fv=0
#            T=self.TfromHl(H)
#        elif H>Hvsat:
#            fv=1
#            T=self.TfromHv(H)
#        else:
#            T=self.TfromPsat(P)
#            fv=(H-Hlsat)/(Hvsat-Hlsat)
#        return T   
        
    def U(self,fva,fvb):
        U=sc.zeros(self.n)
        for i in range(0,self.n):
            
            if fva[i]==0 and fvb[i]==0:
                U[i]=500
            elif (fva[i]>0 and fva[i]<1) and (fvb[i]>0 and fvb[i]<1):
                U[i]=1000
            elif fva[i]==1 and fvb[i]==1:
                U[i]=1000
            elif (fva[i]==1 or fvb[i]==1) and (fva[i]!=fvb[i]):
                U[i]=100
            elif ((fva[i]>0 and fva[i]<1) or (fvb[i]>0 and fvb[i]<1)) and not ((fva[i]>0 and fva[i]<1) and (fvb[i]>0 and fvb[i]<1)):
                U[i]=100
        self.U=U
        return self.U

   
       
        
        