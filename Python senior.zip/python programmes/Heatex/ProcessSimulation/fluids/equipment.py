# -*- coding: utf-8 -*-
"""
Created on Sun Feb 15 09:25:43 2015

@author: Girija
"""

do=10
di=5 
da=4*(do**2-di**2)/(do-di) #hyd dia for annulus
db=di
ma=1  #kmol/s
mb=2  #kmol/s
P=101325 #pa
Tbin=340
Tain=400
n=10
A=500
L=500
Afa=3.142*(do**2-di**2)/4
Afb=3.142*(di**2)/4
ka=0.608
kb=0.142