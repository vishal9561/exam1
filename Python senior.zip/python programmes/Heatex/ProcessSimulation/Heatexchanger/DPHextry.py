# -*- coding: utf-8 -*-
"""
Created on Wed Jan 28 11:02:23 2015

@author: vhd
"""

import scipy as sc
import scipy.optimize as opt
import scipy.integrate as integ
from scipy.integrate import quad
import matplotlib.pyplot as plt


class fluid:
    def __init__(self,T,m):
        self.T=T
        self.m=m
        
    def cp(self,T):
        Cp=(4.184+(10**-4)*T+(10**-6)*T**2+(10**-9)*T**3)*1000
        return Cp


class DPHex:
    def __init__(self,u,a,hot,cold,n):
        self.u=u
        self.a=a
        self.mh=hot.m
        self.mc=cold.m
        self.Thin=hot.T
        self.Tcin=cold.T
        
        self.set_grid(n)
        self.cph=hot.cp
        self.cpc=cold.cp
        
    def set_grid(self,n):
        self.n=n
        self.da=self.a/(n-1)
        self.Th=sc.ones(n)*self.Thin
        self.Tc=sc.ones(n)*self.Tcin
        self.Tguess=sc.concatenate((self.Th,self.Tc))
    def solve(self):
        Tguess=self.Tguess
        Tsoln=opt.leastsq(residuals,Tguess,args=(self))[0]
        self.Th=Tsoln[:self.n]
        self.Tc=Tsoln[self.n:]
        self.Th[0]=self.Thin
        self.Tc[-1]=self.Tcin
        
    def check(self):
        (Hh,er1)=quad(self.cph,self.Th[-1],self.Th[0])
        
        (Hc,er2)=quad(self.cpc,self.Tc[-1],self.Tc[0])
        
        Err=self.mc*Hc-self.mh*Hh
        return Err

        
def residuals(T,obj):
    n=obj.n
    Th=T[:n]
    Tc=T[n:]
    Th[0]=obj.Thin
    Tc[-1]=obj.Tcin
    cph=obj.cph
    cpc=obj.cpc
    u=obj.u
    Thin=obj.Thin
    Tcin=obj.Tcin
    mh=obj.mh
    mc=obj.mc
    da=obj.da
    errHL=(u*(Thin-Tc[0])/(mh*cph(Thin)))+((Th[1]-Thin))/da
    errCL=(u*(Thin-Tc[0])/(mc*cpc(Tc[0])))+((Tc[1]-Tc[0]))/da
    errHR=(u*(Th[-1]-Tcin)/(mh*cph(Th[-1])))+((Th[-1]-Th[-2]))/da
    errCR=(u*(Th[-1]-Tcin)/(mc*cpc(Tcin)))+((Tcin-Tc[-2]))/da
    errH=sc.zeros(n)
    errC=sc.zeros(n)
    errH[0]=errHL
    errH[-1]=errHR
    errC[0]=errCL
    errC[-1]=errCR
    errH[1:-1]=(u*(Th[1:-1]-Tc[1:-1])/(mh*cph(Th[1:-1])))+(Th[2:]-Th[1:-1])/da
    errC[1:-1]=(u*(Th[1:-1]-Tc[1:-1])/(mc*cpc(Tc[1:-1])))+(Tc[2:]-Tc[1:-1])/da
    return sc.concatenate((errH,errC))
    


 
hot=fluid(373,1)
cold=fluid(303,2)
hex1=DPHex(300,100.0,hot,cold,10)  #instance of class DPHex
listn=sc.array([10**i for i in range(1,4)])
listerr=[]
for n in listn:
    hex1.set_grid(n)
    hex1.solve()
    err=hex1.check()
    listerr += [err]
    

print(listerr)    
plt.plot(listn,listerr)
plt.show()


