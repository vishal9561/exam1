# -*- coding: utf-8 -*-
"""
Created on Tue Feb 03 21:47:36 2015

@author: Girija
"""

Thin=373
Tcin=303
mh=1
mc=2
u=300
a=100
n=10