# -*- coding: utf-8 -*-
"""
Created on Tue Jan 20 19:31:51 2015

@author: Nitish
"""

import numpy as np
import matplotlib.pyplot as plt

'''#fixed input
Z = np.array([[0,0,0,0,0,0],
              [0,0,0,1,0,0],
              [0,0,0,1,0,0],
              [0,0,1,1,0,0],
              [0,0,0,0,0,0],
              [0,0,0,0,0,0]])
'''
#randomized input
Z = np.random.randint(0,2,(30,30))
              
N = np.zeros(Z.shape, dtype=int)
N[1:-1,1:-1] += (Z[ :-2, :-2] + Z[ :-2,1:-1] + Z[ :-2,2:] +
                 Z[1:-1, :-2]                + Z[1:-1,2:] +
                 Z[2:  , :-2] + Z[2:  ,1:-1] + Z[2:  ,2:])
                 
def iterate(Z):
    # Count neighbours
    N = (Z[0:-2,0:-2] + Z[0:-2,1:-1] + Z[0:-2,2:] +
         Z[1:-1,0:-2]                + Z[1:-1,2:] +
         Z[2:  ,0:-2] + Z[2:  ,1:-1] + Z[2:  ,2:])

    # Apply rules
    birth = (N==3) & (Z[1:-1,1:-1]==0)
    survive = ((N==2) | (N==3)) & (Z[1:-1,1:-1]==1)
    Z[...] = 0
    Z[1:-1,1:-1][birth | survive] = 1
    return Z
    
fig = plt.figure()
ax=fig.add_subplot(111)

for i in range(100): 
    iterate(Z)
    ax.clear()
    ax.imshow(Z,interpolation='nearest', cmap='binary')
    plt.show()
    plt.pause(0.001)