# -*- coding: utf-8 -*-
"""
Created on Sun Jan 18 13:26:40 2015

@author: Sony
"""

def Cph(T):
    y= 4.184+10^(-4)*T+10^(-6)*T**2+10^(-9)*T**3
    return y
Thin=373; Tcin=303;n=10
import scipy
Thguess=scipy.array(n*[Thin])  # or Thguess=scipy.ones(n)*Thin
Tcguess=scipy.array(n*[Tcin])  # or Tcguess=scipy.ones(n)*Tcin
Tguess=scipy.concatenate((Thguess,Tcguess))
U=300
mh=1
mc=2
A=10
def error(T,U,mh,mc,Thin,Tcin):
   n=len(T)/2
   Th=Tguess[:n] ; Tc=Tguess[n:]
   print Th,Tc
   delA=A/(n-1.0)
   error=((Th(1)-Thin)/delA)+((U*(Th(1)+Thin-Tc(1)-Tcin))/(2*mh*Cph((Th(1)+Th(0))/2)))
   print delA, error
   
   