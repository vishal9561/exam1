import scipy as sc

"""BENZENE""" 

MW = 78.112 #kg/kmol
formula = "C6H6"  
TriplePoint_T = 278.5 #K
Triplepoint_P = 483 #Pa
Ts1=353.2 #K
Ps1=101325 #Pa
R=8.314 #J.mol-1.K-1
Tf=298 #K
#------------------------------------------------------------------------------
'''IDEAL GAS - HEATS AND FREE ENERGIES OF FORMATION'''
Hf = 8.288*10**7 #J/kmol @ 25oC and 1 bar (ideal gas)
Gf = 12.96*10**7 #J/kmol @ 25oC and 1 bar (ideal gas)
Sf = 2.693*10**5 #J/kmol-K @ 25oC and 1 bar (ideal gas)
#------------------------------------------------------------------------------
'''CRITICAL CONSTANTS'''
Tc = 562.05 #K 
Pc = 4.895*10**6 #Pa
Zc = 0.268
Vc = 0.256 #m3/kmol
accf = 0.2103 
#------------------------------------------------------------------------------
'''SPECIFIC HEATS'''

def Cpl(T):     #J/kmol-K
    c1 = 1.2944*10**(-5)
    c2 = -1.6950*10**2
    c3 = 6.4781*10**(-1)
    c4 = 0
    c5 = 0
    cpl = c1+c2*T+c3*T**2+c4*T**3+c5*T**4
    return cpl

def Cpg(T):     #J/mol-K
    return 82.44
#------------------------------------------------------------------------------    
'''VAPORISATION ENTHALPY'''   
def Hvap(T):     #J/kmol between 278.68K and 562.05K
    C1 = 4.5346*10**7
    C2 = 0.39053
    C3 = 0
    C4 = 0
    C5 = 0
    Tr = T/Tc
    Hv = C1*(1-Tr)**(C2 + C3*Tr + C4*Tr**2 + C5*Tr**3)  
    return Hv
#------------------------------------------------------------------------------
'''VAPOR PRESSURE'''    
def Psat(T):     #Pa and T in K
    if T < 373.5 and T > 333.4:
        A = 4.72583
        B = 1660.652
        C = -1.461
    elif T < 318 and T > 297.9:
        A = 0.14591
        B = 39.165
        C = -261.236
    elif T < 554.8 and T > 421.56:
        A = 4.60362
        B = 1701.073
        C = 20.806
        
    k = A - B / (T + C) 
    vp = (10**k) * 10**5
    return vp
#------------------------------------------------------------------------------
'''DENSITY'''    
def rhoL(T):   #kmol/m3 (Trange = 278.68K - 562.16K)
   pass    
def rhoG(T): #kmol/m3 (Trange = 278.68K - 562.16K)
    c1 = 1.0162
    c2 = 0.2655
    c3 = 562.16
    c4 = 0.28212
    rhoL = c1/(c2**(1+(1-(T/c3)**c4)))
    return rhoL 
#------------------------------------------------------------------------------
'''VISCOSITY'''
def Viscl(T):     #J/kmol-K Trange - 10C to 80C
   c1 = 7*10**(9)
   c2 = -4.078
   viscl = c1*T**(c2)
   return viscl 

def Viscg(T):     #J/kmol-K
    pass
#------------------------------------------------------------------------------
'''THERMAL CONDUCTIVITY'''
def kl(T): #Trange= 278.16 - 413.10
    c1 = 0.2344
    c2 = -0.00030572
    c3 = 0
    c4 = 0
    c5 = 0
    k = c1+c2*T+c3*T**2+c4*T**3+c5*T**4
    return k 

def kg(T): #Trange = 339.15 - 1000
    c1 = 0.00001652
    c2 = 1.3117
    c3 = 491
    c4 = 0 
    k = (c1*T**c2)/(1+c3/T+c4/T**2)
    return k
#------------------------------------------------------------------------------    
'''SATURATION TEMPERATURE'''
def Tsat(P):
    Ts = 1/((1/Ts1)-(8.314*sc.log(P/101325))/(Hvap(Ts1)))
    return Ts
     