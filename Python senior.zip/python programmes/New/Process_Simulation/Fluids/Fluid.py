# -*- coding: utf-8 -*-
"""
Created on Wed Jan 28 11:00:01 2015

@author: vhd
"""

import scipy as sc
from scipy.integrate import quad
from scipy.interpolate import UnivariateSpline as us
from Process_Simulation.Heat_Exchanger import op_cond



class Fluid:
    def __init__(self,m,T,fv,fluidproperties):
        self.props = fluidproperties
        p = self.props
        self.m = m
        self.P = op_cond.P
        self.fv = fv
        self.T = T
        self.Psat = p.Psat
        self.Viscl = p.Viscl
        self.Viscg = p.Viscg
        self.Densl = p.Densl
        self.Densg = p.Densg
        self.kl = p.kl
        self.kg = p.kg
        self.Tsat = p.Tsat
        
#        if P < p.Psat(T):
#            self.Cp = p.Cpg
#        else:
#            self.Cp = p.Cpl
    
    def Hl(self,T):
        p = self.props
        
        Hl = p.Hf + quad(p.Cpg,p.Tf,T)[0] - p.Hvap(T)
        return Hl
    
    def Hv(self,T):
        p = self.props
        
        Hv = p.Hf + quad(p.Cpg,p.Tf,T)[0]  
        return Hv
        
    def H(self,T,fv):
        H = (1-fv)*self.Hl(T) + fv*self.Hv(T)
        return H
            
        
#    def interpolate(self,H):
#        
#        Hl1 = sc.zeros(op_cond.n)
#        Hv1 = sc.zeros(op_cond.n)        
#        
#        for i in range (0,op_cond.n):
#            Hl1[i] = self.Hl(temp[i])
#            Hv1[i] = self.Hv(temp[i])
#     
#        Hlsat = self.Hl(self.Tsat(self.P))
#        Hvsat = self.Hv(self.Tsat(self.P))
#        
#        TL = us(Hl1,temp,k=3,s=0)
#        TV = us(Hv1,temp,k=3,s=0)
#
#        if H < Hlsat:
#            T = TL(H)
#            
#        elif H > Hvsat :
#            T = TV(H)
#            
#        else: 
#            T = self.Tsat(self.P)
#        
#        return T