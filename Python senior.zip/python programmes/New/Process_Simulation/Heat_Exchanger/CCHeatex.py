# -*- coding: utf-8 -*-
"""
Creobj.Ated on Wed Jan 28 11:39:40 2015
+
@author: vhd
"""

import scipy as sc
import scipy.integrate as integ
import scipy.optimize as opt
import op_cond
from scipy.interpolate import UnivariateSpline as us
import pylab

temp = sc.linspace(273,573,op_cond.n)

class CCHex:
    def __init__(self,U,n,FA,FB):
        self.U = U
        self.Af = op_cond.Af
        self.At = op_cond.At
        self.L = op_cond.L
        self.FA = FA
        self.FB = FB
        self.n = n
        self.P = op_cond.P
        self.ma = FA.m
        self.mb = FB.m
        self.Thin = FA.T
        self.Tcin = FB.T
        self.kla = FA.kl
        self.klb = FB.kl
        self.kga = FA.kg
        self.kgb = FB.kg
        self.Hai = FA.H(FA.T,FA.fv)
        self.Hbi = FB.H(FB.T,FB.fv)
        self.fvAi = op_cond.fva
        self.fvBi = op_cond.fvb
        self.Tsata = FA.Tsat(op_cond.P)
        self.Tsatb = FB.Tsat(op_cond.P)
        
    def set_grid(self):
        self.dx = self.L/float(op_cond.n-1)
        self.dAt = self.At/float(op_cond.n-1)
        self.Ha = sc.linspace(self.Hai,self.Hai - 5**7,op_cond.n)
        self.Hb = sc.linspace(self.Hbi + 5**7,self.Hbi,op_cond.n)
#        self.Ha = sc.ones(self.n)*self.Hai
#        self.Hb = sc.ones(self.n)*self.Hbi
        self.Hguess = sc.concatenate((self.Ha,self.Hb))
        self.Ta = sc.ones(self.n)*self.Thin
        self.Tb = sc.ones(self.n)*self.Tcin
        
    def solve(self):
        Hguess = self.Hguess
        
        Hla = sc.zeros(op_cond.n)
        Hva = sc.zeros(op_cond.n)
        Hlb = sc.zeros(op_cond.n)
        Hvb = sc.zeros(op_cond.n)
        
        for i in range (0,op_cond.n):
            Hla[i] = self.FA.Hl(temp[i])
            Hva[i] = self.FA.Hv(temp[i])
            Hlb[i] = self.FB.Hl(temp[i])
            Hvb[i] = self.FB.Hv(temp[i])
        
        self.Hlsata = self.FA.Hl(self.Tsata)
        self.Hvsata = self.FA.Hv(self.Tsata)
        self.Hlsatb = self.FB.Hl(self.Tsatb)
        self.Hvsatb = self.FB.Hv(self.Tsatb)
        
        self.TLa = us(Hla,temp,k=3,s=0)
        self.TVa = us(Hva,temp,k=3,s=0)
        self.TLb = us(Hlb,temp,k=3,s=0)
        self.TVb = us(Hvb,temp,k=3,s=0)
               
        soln = opt.leastsq(residuals,Hguess,args=(self))
        Hsoln = soln[0]
        self.HA = Hsoln[:self.n]
        self.HB = Hsoln[self.n:]
        self.HA[0] = self.Hai
        self.HB[-1] = self.Hbi

        self.TA = sc.array([self.interpolate(h,self.Hlsata,self.Hvsata,self.TLa,self.TVa,self.Tsata) for h in self.HA])
        self.TB = sc.array([self.interpolate(h,self.Hlsatb,self.Hvsatb,self.TLb,self.TVb,self.Tsatb) for h in self.HB])
        
        print self.TA
        print self.TB
        
    def interpolate(self,H,Hlsat,Hvsat,TL,TV,Tsat):

        if sc.absolute(H) > sc.absolute(Hlsat):
            t = TL(H)
            
        elif sc.absolute(H) < sc.absolute(Hvsat):
            t = TV(H)
            
        else:
            t = Tsat
            
        return t
     
#    def check(self):
#        errchk=(self.Ha[9]-self.Ha[0])-(self.Hb[0]-self.Hb[-1])
#        i1 = integ.quad(FA.Cp,self.Th[-1],self.Thin)
#        i2 = integ.quad(FB.Cp,self.Tcin,self.Tc[0])
##       print i1
##       print i2
#        i = (self.mh*i1[0]) - (self.mc*i2[0])
#        errchk = (i/(self.mh*i1[0]))*100
#        return errchk      
    def fvap(self,H,Hlsat,Hvsat):
        
        if sc.absolute(H) > sc.absolute(Hlsat):
            fv = 0
        elif sc.absolute(H) < sc.absolute(Hvsat):
            fv = 1
        else:
            fv = (sc.absolute(H) - sc.absolute(Hlsat))/(sc.absolute(Hvsat) - sc.absolute(Hlsat))
        
        return fv        
        
def residuals(Hguess,obj):
    n=obj.n
    
    Tguess = sc.array([obj.interpolate(h,obj.Hlsata,obj.Hvsata,obj.TLa,obj.TVa,obj.Tsata) for h in Hguess])
    Ta = Tguess[:n]
    Tb = Tguess[n:]    
    
    Ha = Hguess[:n]
    Hb = Hguess[n:]
    Ha[0] = obj.Hai
    Hb[-1] = obj.Hbi
      
#    Ta = sc.array([obj.interpolate(h,obj.Hlsata,obj.Hvsata,obj.TLa,obj.TVa,obj.Tsata) for h in Ha])
#    Tb = sc.array([obj.interpolate(h,obj.Hlsatb,obj.Hvsatb,obj.TLb,obj.TVb,obj.Tsatb) for h in Hb])
#    print Ta
#    print Tb
    
#    dhAdx = sc.zeros(n)
#    dhBdx = sc.zeros(n)
#    dhAdx[:-1] = (Ha[1:]-Ha[:-1])/obj.dx
#    dhBdx[:-1] = (Hb[1:]-Hb[:-1])/obj.dx
#    dhAdx[-1] = (Ha[-1]-Ha[-2])/obj.dx
#    dhBdx[-1] = (Hb[-1]-Hb[-2])/obj.dx
##    print dhAdx
##    print dhBdx
#    
#    dTAdx = sc.zeros(n)
#    dTBdx = sc.zeros(n)
#    dTAdx[:-1] = (Ta[1:]-Ta[:-1])/obj.dx
#    dTBdx[:-1] = (Tb[1:]-Tb[:-1])/obj.dx
#    dTAdx[-1] = (Ta[-1]-Ta[-2])/obj.dx
#    dTBdx[-1] = (Tb[-1]-Tb[-2])/obj.dx
##
    Ka = [] 
    for x in range(0,n):
        Ka = sc.append(Ka,obj.fvap(Ha[x],obj.Hlsata,obj.Hvsata)*obj.kga(Ta[x])+(1-obj.fvap(Ha[x],obj.Hlsata,obj.Hvsata)*obj.kla(Ta[x])))
        
    Kb = []
    for x in range(0,n):
        Kb = sc.append(Kb,obj.fvap(Hb[x],obj.Hlsatb,obj.Hvsatb)*obj.kgb(Tb[x])+(1-obj.fvap(Hb[x],obj.Hlsatb,obj.Hvsatb)*obj.klb(Tb[x])))         
    
#    dKa = sc.zeros(n)
#    dKb = sc.zeros(n)
#    
#    dKa[-1] = (Ka[-1]*obj.Af*dTAdx[-1]-Ka[-2]*obj.Af*dTAdx[-2])/obj.dx 
#    dKa[:-1] = (Ka[1:]*obj.Af*dTAdx[1:]-Ka[:-1]*obj.Af*dTAdx[:-1])/obj.dx 
#    
#    dKb[-1] = (Kb[-1]*obj.Af*dTBdx[-1]-Kb[-2]*obj.Af*dTBdx[-2])/obj.dx 
#    dKb[:-1] = (Kb[1:]*obj.Af*dTBdx[1:]-Kb[:-1]*obj.Af*dTBdx[:-1])/obj.dx 
#
#    errA = sc.zeros(n)
#    errB = sc.zeros(n) 
#    
#    errA[:] = obj.ma*dhAdx[:]+obj.U*(obj.dAt/obj.dx)*(Ta[:]-Tb[:])-dKa[:]
#    errB[:] = obj.mb*dhBdx[:]+obj.U*(obj.dAt/obj.dx)*(Ta[:]-Tb[:])+dKb[:]   
    
    errAL = obj.Af*((Ka[1]-Ka[0])/(obj.dx))*((Ta[1]-Ta[0])/obj.dx)+Ka[0]*obj.Af*((Ta[2]-2*Ta[1]+Ta[0])/obj.dx**2)-obj.ma*((Ha[1]-Ha[0])/obj.dx)-obj.U*(obj.dAt/obj.dx)*(Ta[0]-Tb[0])
    errBR = obj.Af*((Kb[-1]-Kb[-2])/(obj.dx))*((Tb[-1]-Tb[-2])/obj.dx)+Kb[-1]*obj.Af*((Tb[-1]-2*Tb[-2]+Tb[-3])/obj.dx**2)+obj.mb*((Hb[-1]-Hb[-2])/obj.dx)+obj.U*(obj.At/obj.dx)*(Ta[0]-Tb[0])

    errAR = obj.Af*((Ka[-1]-Ka[-2])/(obj.dx))*((Ta[-1]-Ta[-2])/obj.dx)+Ka[-1]*obj.Af*((Ta[-1]-2*Ta[-2]+Ta[-3])/obj.dx**2)-obj.ma*((Ha[-1]-Ha[-2])/obj.dx)-obj.U*(obj.At/obj.dx)*(Ta[-1]-Tb[-1])
    errBL = obj.Af*((Kb[1]-Kb[0])/(obj.dx))*((Tb[1]-Tb[0])/obj.dx)+Kb[0]*obj.Af*((Tb[2]-2*Tb[1]+Tb[0])/obj.dx**2)-obj.mb*((Hb[1]-Hb[0])/obj.dx)-obj.U*(obj.dAt/obj.dx)*(Ta[0]-Tb[0])
    
    errA=sc.zeros(n)
    errB=sc.zeros(n)
   
    errA[0]=errAL; errA[-1]=errAR
    errB[0]=errBL; errB[-1]=errBR

    errA[1:-1] = obj.Af*((Ka[2:]-Ka[:-2])/(2*obj.dx)+Ka[1:-1]*((Ta[2:]-2*Ta[1:-1]+Ta[:-2])/obj.dx**2))-obj.ma*((Ha[2:]-Ha[:-2])/2*obj.dx)-obj.U*(Ta[1:-1]-Tb[1:-1])*(obj.dAt/obj.dx)
    errB[1:-1] = obj.Af*((Kb[2:]-Kb[:-2])/(2*obj.dx)+Kb[1:-1]*((Tb[2:]-2*Tb[1:-1]+Tb[:-2])/obj.dx**2))-obj.mb*((Hb[2:]-Hb[:-2])/2*obj.dx)-obj.U*(Ta[1:-1]-Tb[1:-1])*(obj.dAt/obj.dx)

    err = sc.concatenate((errA,errB))
    
    return err
        
