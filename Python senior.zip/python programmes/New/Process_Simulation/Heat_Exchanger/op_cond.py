# -*- coding: utf-8 -*-
"""
Created on Mon Feb  2 20:40:00 2015

@author: Samsung
"""
P = 3*101325.0 #Pa  Operating pressure

Thin = 373.15 #K Hot fluid inlet temp

Tcin = 303.15 #K Cold fluid inlet temp

ma = 5 #kmol/s Mass flow rate of A

mb = 10 #kmol/s Mass flow rate of B

fva = 0 #Inlet vapour fraction of A

fvb = 0 #Inlet vapour fraction of B

Af = 3 #m^2 Flow area

At = 30 #m^2 Area of heat transfer

L = 10 #m Length of Heat Exchanger

n = 25