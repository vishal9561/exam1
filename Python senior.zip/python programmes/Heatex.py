# -*- coding: utf-8 -*-
"""
Spyder Editor

This temporary script file is located here:
C:\Users\vhd\.spyder2\.temp.py
"""

import scipy as sc
import scipy.optimize as opt
import matplotlib.pyplot as plt

mh=1 #kg/s
mc=1 #kg/s
Thin=373.15 #K
Tcin=303.15 #K
U=300 #W/m^2K
A=100 #m^2
n=10
Thguess=n*[10] #defined as lists
Tcguess=n*[10] #defined as lists
Tguess=sc.array(Thguess+Tcguess) #we want to use this concatenated list as an array so defining

def CpH(T):
    Cp=1000*(4.184+T*10**(-3)+(T**2)*(10**(-6))+(T**3)*(10**(-9)))
    return Cp
    
def CpC(T):
    Cp=1000*(4.184+T*10**(-3)+(T**2)*(10**(-6))+(T**3)*(10**(-9)))
    return Cp
'''print CpH(330) #function call for CpH(T) with T=330'''

for i in range(1,4);:
    listn=sc.array(10**i)
    
for n in listn:
    def residuals(T,U,A,thin,tcin,mh,mc):
        n=len(T)
        Th=T[:n/2]
        Tc=T[n/2:]
        dA=A/((n/2)-1)
        errHL= U*(Thin-Tc[0])/(mh*CpH(Thin))+(Th[1]-Thin)/dA
        errCL= U*(Thin-Tc[0])/(mc*CpC(Tc[0]))+(Tc[1]-Tc[0])/dA
        errHR= U*(Th[-1]-Tcin)/(mh*CpH(Th[-1]))+(Th[-1]-Th[-2])/dA
        errCR= U*(Th[-1]-Tcin)/(mc*CpC(Tcin))+(Tcin-Tc[-2])/dA
        errH=sc.zeros(n/2)
        errC=sc.zeros(n/2)
        errH[0]=errHL; errH[-1]=errHR
        errC[0]=errCL; errC[-1]=errCR
        errH[1:-1]=U*(Th[1:-1]-Tc[1:-1])/(mh*CpH(Th[1:-1]))+(Th[2:]-Th[1:-1])/dA
        errC[1:-1]=U*(Th[1:-1]-Tc[1:-1])/(mc*CpC(Tc[1:-1]))+(Tc[2:]-Tc[1:-1])/dA
        return sc.concatenate((errH,errC))
    
    soln=opt.leastsq(residuals,Tguess,args=(U,A,Thin,Tcin,mh,mc))
    Tsoln=soln[0]
    Thsoln= Tsoln[:n/2]; Thsoln[0]=Thin
    Tcsoln= Tsoln[n/2:]; Tcsoln[-1]=Tcin
    print Tsoln
