# -*- coding: utf-8 -*-
"""
Created on Wed Jan 21 11:37:30 2015

@author: vhd
"""

class Dog:
    nlegs=4                 #attribute1 of class
    nnose=1                 #attribute2 of class
    def makesound(self):    #attribute3 of class
        print "woof"
    
pup=Dog()                   #pup is an element of class Dog having attributes in defined in class
lamepup=Dog()               #lamepup is another element
lamepup.nlegs=3             #changing nlegs attribute of lamepup
print pup.nlegs,lamepup.nlegs
pup.makesound()