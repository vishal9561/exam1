import scipy as sp
import matplotlib.pyplot as plt
import scipy.optimize as opt
from scipy.integrate import quad
#-------------------------------------------------------------------------------------------------------
c1=4184
c2=0.1
c3=0.001
c4=10**(-6)
def Cph(T):
    cp=c1+c2*T+c3*T**2+c4*T**3
    return cp
def Cpc(T):
    cp=c1+c2*T+c3*T**2+c4*T**3
    return cp
#-------------------------------------------------------------------------------------------------------    
def error(Tguess,obj):
    n=len(Tguess)
    Th=sp.array(Tguess[:n/2]);Th[0]=obj.Th_in
    Tc=sp.array(Tguess[n/2:]);Tc[-1]=obj.Tc_in
    errHL=(obj.U*(obj.Th_in-Tc[0]))/(obj.mh*obj.Cph(obj.Th_in))+(Th[1]-obj.Th_in)/obj.dA
    errCL=(obj.U*(obj.Th_in-Tc[0]))/(obj.mc*obj.Cpc(Tc[0]))+(Tc[1]-Tc[0])/obj.dA
    errHR=(obj.U*(Th[-1]-obj.Tc_in))/(obj.mh*obj.Cph(Th[-1]))+(Th[-1]-Th[-2])/obj.dA
    errCR=(obj.U*(Th[-1]-obj.Tc_in))/(obj.mc*obj.Cpc(obj.Tc_in))+(obj.Tc_in-Tc[-2])/obj.dA
    errH=sp.zeros(n/2)
    errC=sp.zeros(n/2)
    errH[0]=errHL;errH[-1]=errHR
    errC[0]=errCL;errC[-1]=errCR
    #FORWARD DIFFERENCE OPERATION 
    errH[1:-1]=obj.U*(Th[1:-1]-Tc[1:-1])/(obj.mh*obj.Cph(Th[1:-1]))+(Th[2:]-Th[1:-1])/obj.dA
    errC[1:-1]=obj.U*(Th[1:-1]-Tc[1:-1])/(obj.mc*obj.Cpc(Tc[1:-1]))+(Tc[2:]-Tc[1:-1])/obj.dA
    return sp.concatenate((errH,errC))
#-------------------------------------------------------------------------------------------------------    
class Cold(object):
     def __init__(self,mc,Tc_in,Cpc):
         self.mc=mc
         self.Tc_in=Tc_in
         self.Cpc=Cpc

class Hot(object):
    def __init__(self,mh,Th_in,Cph):
        self.Th_in=Th_in
        self.mh=mh
        self.Cph=Cph 
#-------------------------------------------------------------------------------------------------------
class DHCPx(object):
    def __init__(self,A,U,Cold,Hot): 
        self.A=A
        self.Tc_in=Cold.Tc_in
        self.U=U
        self.Th_in=Hot.Th_in
        self.mc=Cold.mc
        self.mh=Hot.mh 
        self.Cpc=Cold.Cpc
        self.Cph=Hot.Cph
        
    def set_grid(self,n):
        self.n=n
        self.Tc=sp.ones(self.n)*self.Tc_in
        self.Th=sp.ones(self.n)*self.Th_in
        self.dA=float(self.A)/float((self.n-1))
        self.Tguess=sp.concatenate((self.Th,self.Tc))
    
    
    def solve(self):
        soln=opt.leastsq(error,self.Tguess,args=(self))
        Tsoln=soln[0]
        self.Th_correct=Tsoln[:self.n] 
        self.Tc_correct=Tsoln[self.n:]
        return self.Tc_correct
        return self.Th_correct 
        
    def check(self):
        #Tref=298 
        #H_hin=quad(Cph,Tref,self.Th_in)
        #H_cin=quad(Cpc,Tref,self.Tc_in)
        #H_hout=quad(Cph,Tref,self.Th_correct[-1])
        #H_cout=quad(Cpc,Tref,self.Tc_correct[0])
        #H_IN=self.mh*H_hin[0]+self.mc*H_cin[0]
        #H_OUT=mh*H_hout[0]+mc*H_cout[0]
        H_hoverall=quad(self.Cph,self.Th_in,self.Th_correct[-1])
        H_coverall=quad(self.Cpc,self.Tc_in,self.Tc_correct[0])
        Hacc=self.mh*H_hoverall[0]+self.mc*H_coverall[0]
        return Hacc
#-------------------------------------------------------------------------------------------------------        
nrange=sp.linspace(10,1000,5)
listerr=[]
'''
#FIRST HE 
Cold1=Cold(2,303.16,Cpc) 
Hot1=Hot(1,373.16,Cph)
he1=DHCPx(10,300,Cold1,Hot1)
he1.set_grid(100)
he1.solve()
#SECOND HE 
Cold2=Cold(2,he1.Tc_correct[0],Cpc) 
Hot2=Hot(1,he1.Th_correct[-1],Cph)
he2=DHCPx(10,300,Cold2,Hot2)
he2.set_grid(100)
he2.solve()
Th_correct=sp.concatenate((he1.Th_correct,he2.Th_correct))
Arange=sp.linspace(0,20,200)
plt.plot(Arange,Th_correct)
#plt.plot(Arange,he2.Th_correct)
'''
for n in nrange: 
    Cold1=Cold(2,303.16,Cpc) 
    Hot1=Hot(1,373.16,Cph)
    hex1=DHCPx(10,300,Cold1,Hot1)
    hex1.set_grid(n)
    hex1.solve()
    err=hex1.check()
    listerr+=[err]
#-------------------------------------------------------------------------------------------------------
plt.plot(nrange,listerr)  
plt.title("Error vs grid size")
plt.xlabel("mesh size") 
plt.ylabel('Error')  
