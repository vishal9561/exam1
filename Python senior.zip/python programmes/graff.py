# -*- coding: utf-8 -*-
"""
Created on Mon Jan 19 10:22:32 2015

@author: Nitish
"""
import scipy as sp 
import matplotlib.pyplot as plt
a=sp.linspace(-2*sp.pi,2*sp.pi,100)

fig=plt.figure()
ax=fig.add_subplot(111)
fig.show()
for i in range(0,5):
    for r in sp.linspace(0.1,10,100):
         x=r*sp.cos(a)
         y=r*sp.sin(a)
         ax.plot(x,y)
         plt.ylim(-10,10)
         plt.xlim(-10,10)
         plt.pause(0.01)
    ax.clear()    
    
    
    for r in sp.linspace(10,0.1,100):
         x=r*sp.cos(a)
         y=r*sp.sin(a)
         ax.plot(x,y)
         plt.ylim(-10,10)
         plt.xlim(-10,10)
         plt.pause(0.01)
    
    ax.clear()
    