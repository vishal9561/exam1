# -*- coding: utf-8 -*-
"""
Created on Wed Jan 07 11:07:49 2015

@author: vhd
"""
import os

print "Hello"
x=0.14

if x>1:
    print x
    print 'x greater than 1'
    print 'x>1'
elif x<4:
    print x
    print 'x<4'
else:
    print x
y=[1.0,3,'cat',True,'pony',False,'three blind mice',os]     
for i in range(len(y)):
    print y[i],i
x=range(101)
y=[z**2 for z in x]
import pylab
pylab.plot(x,y,'#FFF8E7')
pylab.show()