# -*- coding: utf-8 -*-
"""
Created on Wed Jan 14 10:26:46 2015

@author: vhd
"""

import scipy as sc
from matplotlib import pyplot as plt
def f1(x):
    y=sc.cos(x)
    return y
def f2(x):
    y=sc.cos(2*x)
    return y
f3=lambda x:sc.cos(3*x)
f4=lambda x:sc.cos(4*x)
listf=[f1,f2,f3,f4]
fig=plt.figure()
ax=fig.add_subplot(211)
ax2=fig.add_subplot(212)
fig.show()
x=sc.linspace(0,sc.pi*2,1000)
for f in listf:
    y=f(x)
    ax.clear()
    ax2.clear()
    ax.plot(x,y,'r')
    ax2.plot(x,y,'r')
    plt.pause(2)
    
    