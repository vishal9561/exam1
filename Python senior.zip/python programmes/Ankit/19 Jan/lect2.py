# -*- coding: utf-8 -*-
"""
Created on Tue Jan 13 11:43:22 2015

@author: vhd
"""
import scipy
import matplotlib.pyplot as plt
x = scipy.linspace(0, 2*scipy.pi, 1000)
def f1(x):
    return scipy.cos(x)
def f2(x):
    return scipy.cos(2*x)
f3 = lambda x : scipy.cos(3*x)
f4 = lambda x : scipy.cos(4*x)
listf = [f1, f2, f3, f4]
fig=plt.figure()
ax=fig.add_subplot(111);fig.show()
for f in listf:
    y=f(x)
    ax.clear()
    ax.plot(x, y, 'r')
    plt.pause(0.001)
