# -*- coding: utf-8 -*-
"""
Created on Tue Jan 13 10:02:59 2015

@author: vhd
"""

import scipy,pylab
ydata = [0, 1.3, 3.6]
xdata = [0, 1, 2]
pp = scipy.polyfit(xdata, ydata, 2)
pylab.plot(xdata, ydata, 'r')

print pp
pylab.show()