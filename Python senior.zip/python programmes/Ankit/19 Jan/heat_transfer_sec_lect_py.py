# -*- coding: utf-8 -*-
"""
Created on Wed Jan 14 11:08:02 2015

@author: vhd
"""

import scipy as sc
import scipy.optimize as opt
from matplotlib import pyplot as plt
mh=1  #kg/s
mc=1 #kg/s
thin=373.15 #K
tcin=303.15 #K
u=300 #W/m2.K
a=100 #m2
n=10
thguess =n*[thin]
tcguess=n*[tcin]
tguess=sc.array(thguess+tcguess)
def cph(t):
    cp=4.184+t*10**(-4)+t**2*10**(-6)+t**3*10**(-9)
    return cp
def cpc(t):
    cp=4.184+t*10**(-4)+t**2*10**(-6)+t**3*10**(-9)
    return cp
def residuals(t,u,a,thin,tcin,mh,mc):
    n=len(t)
    th=t[:n/2]
    tc=t[n/2:]
    da=a/((n/2)-1)
    errhl=u*(thin-tc[0])/(mh*cph(thin))+(th[1]-thin)/da
    errcl=u*(thin-tc[0])/(mc*cpc(tc[0]))+(tc[1]-tc[0])/da
    errhr=u*(th[-1]-tcin)/(mh*cph(th[-1]))+(th[1]-thin)/da
    errcr=u*(th[-1]-tcin)/(mc*cpc(tcin))+(tcin-tc[-2])/da
    errh=sc.zeros(n/2)
    errc=sc.zeros(n/2)
    errh[0]=errhl;errh[-1]=errhr
    errc[0]=errcl;errc[-1]=errcr
    errh[1:-1]=u*(th[1:-1]-tc[1:-1])/(mh*cph(th[1:-1]))+(th[2:]-th[1:-1])/da
    #errh[1:-1]=u*(th[1:-1]-tc[1:-1])/(mh*cph(th[1:-1]))+(th[2:]-th[0:-2])/2*da for central diff
    errc[1:-1]=u*(th[1:-1]-tc[1:-1])/(mh*cpc(tc[1:-1]))+(tc[2:]-tc[1:-1])/da
    return sc.concatenate((errh,errc))
soln=opt.leastsq(residuals,tguess,args=(u,a,thin,tcin,mh,mc))
tsoln=soln[0]
thsoln=tsoln[:n/2];thsoln[0]=thin
tcsoln=tsoln[n/2:];tcsoln[-1]=tcin
print thsoln
