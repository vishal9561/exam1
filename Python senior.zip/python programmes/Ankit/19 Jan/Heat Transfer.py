# -*- coding: utf-8 -*-
"""
Created on Tue Jan 13 11:55:53 2015

@author: vhd
"""
import scipy
def Cp(T):
    return 4.184+(T*10**(-4))+((T**2)*10**(-6))+((T**3)*10**(-9))
Thin=373
Tcin=303
n=10
Thguess=scipy.array(n*[Thin])  #Thguess=scipy.ones(n)*Thin
Tcguess=scipy.array(n*[Tcin])
Tguess=scipy.concatenate((Thguess, Tcguess))
def error(T, U, mh, mc, Thin, Tcin):
    n=len(T)/2
    Th=T[:n];Tc=T[n:]/