# -*- coding: utf-8 -*-
"""
Created on Tue Jan 13 10:09:44 2015

@author: vhd
"""

for x in range(0,10):
    print(x)
print('\n')
grocery_list = ['juice','tomatoes']
for y in grocery_list:
    print(y)
