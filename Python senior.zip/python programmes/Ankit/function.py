# -*- coding: utf-8 -*-
"""
Created on Tue Jan 13 10:18:14 2015

@author: vhd
"""

def square(n):
    squared = n**2
    print("%d is the square of %d"%(squared,n))
x = int(raw_input("enter a value: "))
square(x)