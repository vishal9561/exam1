# -*- coding: utf-8 -*-
"""
Created on Tue Jan 27 12:01:27 2015

@author: vhd
"""

class DPHex:
    def __init__(self,di,do,L,flann,flpipe)