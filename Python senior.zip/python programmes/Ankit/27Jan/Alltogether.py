# -*- coding: utf-8 -*-
"""
Created on Tue Jan 27 11:58:15 2015

@author: vhd
"""

import scipy
from Hex import DPHex   #from file name Hex.py import class DPHex
from Fluid_27_1_2015 import Fluid  
import water,benzene
import op_cond   #operation condition ; also a container.
Water=Fluid(water,op_cond.annulusflowrate,op_cond.annulusTemp)   #Fluid takes one argument so water
#In future i may need more fluid props. so op_cond does this for u
Benzene=Fluid(benzene,op_cond.pipeflowrate,op_cond.pipeTemp)
dphex1=DPHex(op_cond.di,op_cond.do,op_cond.L,Water,Benzene)
dphex2=DPHex(op_cond.di,op_cond.do,op_cond.L,Benzene,Water)
print dphex2































