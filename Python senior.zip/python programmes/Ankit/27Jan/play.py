# -*- coding: utf-8 -*-
"""
Created on Tue Jan 27 11:20:30 2015

@author: vhd
"""

import toy as ty
print ty.m
import pylab,scipy
x=scipy.linspace(0,ty.m,100)
f=[ty.f(xx,ty.m) for xx in x]    #ty.f takes 2 arguments as per defined in toy.py
g=[ty.g(xx) for xx in x]
pylab.plot(x,f,'r')
pylab.plot(x,g,'g')
pylab.show()

