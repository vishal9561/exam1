# -*- coding: utf-8 -*-
"""
Created on Tue Jan 27 11:17:25 2015

@author: vhd
"""

m=10.0
f=lambda x,y:x**2+y**2  
def g(x):
    if x>0:
        return x
    else:
        return x*(-1)