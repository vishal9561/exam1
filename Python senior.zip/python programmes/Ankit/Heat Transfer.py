# -*- coding: utf-8 -*-
"""
Created on Tue Jan 13 11:55:40 2015

@author: vhd
"""

import scipy
Cp = lambda T: 4.184 + 10**(-4)*T + 10**(-6)*T**2 + 10**(-9)*T**3
Thin = 373.16
Tcin = 303.16
n = 10
Thguess = scipy.array(n*[Thin]) # Thguess = scipy.ones(n)*Thin
Tcguess = scipy.array(n*[Tcin])
Tguess = scipy.concatenate((Thguess,Tcguess))
def error(T,U,mh,mc,Thin,Tcin,A):
    n = len(T)/2
    Th = T[:n]; Tc = T[n:]
    dA = A/(n-1)
    eh0 = (Th[1]-Thin)/dA + U*(Thin-Tc[0])/(mh*Cp(Thin))
    ec0 = (Tc[1]-Tc[0])/dA + U*(Thin-Tc[0])/(mc*Cp(Tc[0]))
    eh9 = (Th[9]-Th[8])/dA + U*(Th[9]-Tcin)/(mh*Cp(Th[9]))
    ec9 = (Th[9]-Th[8])/dA + U*(Th[9]-Tcin)/(mh*Cp(Tcin))
    return eh0, eh9, ec0, ec9
eh0, eh9, ec0, ec9 = error(Tguess,5,1,2,Thin,Tcin,10)
print eh0, eh9, ec0, ec9