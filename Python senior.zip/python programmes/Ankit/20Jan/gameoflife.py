# -*- coding: utf-8 -*-
"""
Created on Mon Jan 19 23:16:38 2015

@author: Ankit
"""

import numpy as np
from matplotlib import pyplot as plt
import scipy as sc
from random import randint
rows=44
cols=44
Z=np.random.randint(0,2,(rows,cols))

Z[0,:]=0
Z[:,cols-1]=0
Z[:,0]=0
Z[rows-1,:]=0
print Z

print
#Defining neighbours
def neighbours(Z):
    rows=len(Z)
    cols=len(Z[0])
    N=np.random.randint(0,1,(rows,cols)) #creates a random array of size Z
    
    for x in range (1,rows-1):
        for y in range (1,cols-1):
               N[x][y]=Z[x-1][y-1]+Z[x-1][y]+Z[x-1][y+1]+Z[x][y-1]+Z[x][y+1]+Z[x+1][y-1]+Z[x+1][y]+Z[x+1][y+1]
    return N

#Iterating as per rules
def iterate(Z):
    rows,cols = len(Z), len(Z[0])
    N = neighbours(Z)
    for x in range(1,rows):
        for y in range(1,cols):
            if Z[x][y] == 1 and (N[x][y] < 2 or N[x][y] > 3):
                Z[x][y] = 0
            elif Z[x][y] == 0 and N[x][y] == 3:
                Z[x][y] = 1
    return Z 
    

fig=plt.figure()
Zs=[Z]
ims = []
ax=fig.add_subplot(111)
fig.show()


for i in range(0, 100):
    ax.clear()    
    im = ax.imshow(Zs[len(Zs)-1], interpolation = 'nearest', cmap='flag')
    ims.append([im])
    Zs.append(iterate(Zs[len(Zs)-1]))
    plt.pause(0.01)

print Zs
    

    