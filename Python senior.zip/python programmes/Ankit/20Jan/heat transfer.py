# -*- coding: utf-8 -*-

"""

Created on Wed Jan 14 11:04:09 2015



@author: vhd

"""



import scipy as sc

import matplotlib.pyplot as plt

import scipy.optimize as opt

mh=1 #kg/s

mc=2 #kg/s

Thin=373.15 #K

Tcin=303.15 #K

U=300 #W/m2K



A=10#m2

n=10

Thguess=n*[Thin] #guess is inlet value eg 10*[3] is  ten times 3 array

Tcguess=n*[Tcin] #no of elements in an array

Tguess=sc.array(Thguess+Tcguess) #if you add lists they concatenate, arrays add,

#here theys are lists 8



def Cp(T):

    Cp=(4.184+(10**-9)*T**3+(10**-6)*T**2+(10**-4)*T)

    return Cp




 #arrays element which you ant to modify to minimise the residual has to be the first argument for the function



def errors(T,U,A,Thin,Tcin,mh,mc):

    n=len(T)

    Th=T[:n/2] #first n/2 elements to the left of n/2

    Tc=T[n/2:]

    dA=A/((n/2)-1) #unknowns at boundaries also, so n/2-1 parts thus divide are

    errHL=(U*(Thin-Tc[0])/(mh*Cp(Thin)*1000))+((Th[1]-Thin)/dA)

    errCL=(U*(Thin-Tc[0])/(mc*Cp(Tc[0])*1000))+((Tc[1]-Tc[0])/dA)

    errHR=(U*(Th[-1]-Tcin)/(mh*Cp(Th[-1])*1000))+((Th[-1]-Th[-2])/dA)
    errCR=(U*(Th[-1]-Tcin)/(mc*Cp(Tcin)*1000))+((Tcin-Tc[-2])/dA)

    errH=sc.zeros(n/2) #creates an array wid zeros n times i.e., 10 times

    errC=sc.zeros(n/2)

    errH[0]=errHL; errH[-1]=errHR #errors at boundary points

    errC[0]=errCL;errC[-1]=errCR

    errH[1:-1]=(U*(Th[1:-1]-Tc[1:-1])/(mh*Cp(Th[1:-1])*1000))+((Th[2:])-Th[1:-1])/dA

    #forward

    errC[1:-1]=(U*(Th[1:-1]-Tc[1:-1])/(mc*Cp(Tc[1:-1])*1000))+((Tc[2:])-Tc[1:-1])/dA

    #forward

    

    # errH[1:-1]=(u*(th[1:-1]-tc[1:-1])/(mh*Cph(Th[1:-1])))+(th[2:])-th[0:-2])/dA

    #central

    #errC[1:-1]=(u*(th[1:-1]-tc[1:-1])/(mc*Cpc(Tc[1:-1])))+(tc[2:])-tc[0:-2])/dA

    #central

    

    return sc.concatenate((errH,errC))

    

n=len(Tguess)   

soln=opt.leastsq(errors,Tguess,args=(U,A,Thin,Tcin,mh,mc)) #calculates the temp by least square method

Tsoln=soln[0]

Thsoln=Tsoln[:n/2]

Thsoln[0]=Thin

Tcsoln=Tsoln[n/2:]

Tcsoln[-1]=Tcin

    

print Thsoln

print Tcsoln
b=sc.linspace(0,A,10)
plt.plot(b, Thsoln,'r')
plt.show()
plt.plot(b,Tcsoln,'b')
plt.show()
    

    

    

    

    

    

    



