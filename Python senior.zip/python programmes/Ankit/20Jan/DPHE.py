# -*- coding: utf-8 -*-
"""
Created on Tue Jan 20 13:07:51 2015

@author: vhd
"""

import scipy as sc

import matplotlib.pyplot as plt

import scipy.optimize as opt

class DPHE:
    def __init__(self,A,U,mh,mc,Thin,Tcin,n):
        self.Area=A
        self.U=U
        self.set_hex(mh,mc,Thin,Tcin)
        self.set_grid(n)
        self.set_Cp(Cp)
    def set_hex(self,mh,mc,Thin,Tcin):
        self.mh=mh
        self.mc=mc
        self.Thin=Thin
        self.Tcin=Tcin
    def set_grid(self,n):
        self.n=n
        self.Th=sc.ones(n)*self.Thin
        self.Tc=sc.ones(n)*self.Tcin
        self.dA=self.A/((n/2)-1)
        self.Tguess=sc.concatenate((self.Th,self.Tc))
    def set_Cp(self,T):
        self.Cp=(4.184+(10**-9)*T**3+(10**-6)*T**2+(10**-4)*T)

    return Cp
def residuals(T,obj):    #defined outsidwe the class
    n=obj.n
    Thin=obj.Thin
    Tcin=obj.Tcin
    Th=T[:n/2]
    Tc=T[n/2:n]
    dA=obj.dA
    U=obj.U
    mh=obj.mh
    mc=obj.mc
    Cp=obj.Cp
    errHL=(U*(Thin-Tc[0])/(mh*Cp(Thin)*1000))+((Th[1]-Thin)/dA)

    errCL=(U*(Thin-Tc[0])/(mc*Cp(Tc[0])*1000))+((Tc[1]-Tc[0])/dA)

    errHR=(U*(Th[-1]-Tcin)/(mh*Cp(Th[-1])*1000))+((Th[-1]-Th[-2])/dA)
    errCR=(U*(Th[-1]-Tcin)/(mc*Cp(Tcin)*1000))+((Tcin-Tc[-2])/dA)

    errH=sc.zeros(n/2) #creates an array wid zeros n times i.e., 10 times

    errC=sc.zeros(n/2)

    errH[0]=errHL; errH[-1]=errHR #errors at boundary points

    errC[0]=errCL;errC[-1]=errCR

    errH[1:-1]=(U*(Th[1:-1]-Tc[1:-1])/(mh*Cp(Th[1:-1])*1000))+((Th[2:])-Th[1:-1])/dA

    #forward

    errC[1:-1]=(U*(Th[1:-1]-Tc[1:-1])/(mc*Cp(Tc[1:-1])*1000))+((Tc[2:])-Tc[1:-1])/dA

    #forward

    

    # errH[1:-1]=(u*(th[1:-1]-tc[1:-1])/(mh*Cph(Th[1:-1])))+(th[2:])-th[0:-2])/dA

    #central

    #errC[1:-1]=(u*(th[1:-1]-tc[1:-1])/(mc*Cpc(Tc[1:-1])))+(tc[2:])-tc[0:-2])/dA

    #central

    

    return sc.concatenate((errH,errC))
    def solve(self):
        Tguess=self.Tguess
        Tsoln=opt.leastsq(residuals,Tguess,args=(self))
#all the attributes of self are available for this function solve
        self.Th=Tsoln[:self.n/2]
        self.Th[0]=self.Thin
        self.Tc=Tsoln[self.n/2:]
        self.Th[-1]=self.Tcin
        