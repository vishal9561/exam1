# -*- coding: utf-8 -*-
"""
Created on Tue Jan 20 10:52:02 2015

@author: vhd
"""

import scipy
import matplotlib.pyplot as plt
fig = plt.figure()
ax = fig.add_subplot(111)
fig.show()
x = scipy.arange(-1,1.001,0.001)  #(start,stop,step)
a = scipy.arange(0,-2*scipy.pi,-0.05)
for i in range(1,100):
    for z in a:
        y = scipy.tan(z)*x
        
        ax.clear()  
        ax.plot(x,y)
        plt.xlim(-1,1)  #to get the desired graph within the specified limits
        
        plt.ylim(-1,1)
        plt.pause(0.00001)
    i=+1