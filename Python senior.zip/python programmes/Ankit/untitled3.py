# -*- coding: utf-8 -*-
"""
Created on Tue Jan 13 11:01:53 2015

@author: vhd
"""

x = int(raw_input("enter a value: "))
y = x**2
print y