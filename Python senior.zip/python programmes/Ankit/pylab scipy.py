# -*- coding: utf-8 -*-
"""
Created on Tue Jan 13 10:35:45 2015

@author: vhd
"""

import scipy,pylab
xdata= [0,1,2]
ydata = [0,1.3,3.6]
m = scipy.polyfit(xdata,ydata,2)
y = scipy.polyval(m,xdata)
pylab.plot(xdata,ydata,'r')
print m
pylab.plot(xdata,y,'b')
pylab.show()