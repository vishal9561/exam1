# -*- coding: utf-8 -*-
"""
Spyder Editor

This temporary script file is located here:
C:\Users\vhd\.spyder2\.temp.py
"""

'''Interactive plotting'''
import scipy as sc
import matplotlib.pyplot as plt
def f1(x):
    y=sc.cos(x)
    return y     
def f2(x):
    y=sc.cos(2*x)
    return y    
f3=lambda x: sc.cos(3*x)    
f4=lambda x: sc.cos(4*x)
'''18 and 19 is another way of defining functions. lambda is in-line definition'''
listf=[f1,f2,f3,f4]

fig=plt.figure()
ax=fig.add_subplot(111)
fig.show()
x=sc.linspace(0,sc.pi*2,1000)
for f in listf:
    y=f(x)
    '''ax.clear()'''
    ax.plot(x,y,'r')
    plt.pause(1)
